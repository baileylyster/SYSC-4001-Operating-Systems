Steps for simulation

change line 265 for setScheduling to 1,2,3 for the different scheduler types! 2 works best!

compile, build, execute.

The output.txt file will show all the state changes and most ticks for all the processes.

